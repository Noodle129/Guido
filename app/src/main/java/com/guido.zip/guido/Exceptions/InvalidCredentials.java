package com.guido.Exceptions;

public class InvalidCredentials extends Exception {
    public InvalidCredentials() {
        super();
    }
}
