package com.guido.Exceptions;
public class CannotAcessDataBase extends Exception{
}
