package com.guido.JDBC;

public class JDBConstants {
    public static final String DRIVER_NAME = "com.mysql.cj.jdbc.Driver";
    public static final String URL = "jdbc:mysql://guido-db.mysql.database.azure.com:3306/guidoo?useSSL=true";
    public static final String USERNAME = "adminguido";
    public static final String PASSWORD = "123SQLserver123";


}